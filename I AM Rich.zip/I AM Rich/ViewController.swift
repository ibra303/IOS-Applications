//
//  ViewController.swift
//  I AM Rich
//
//  Created by Habib Naif Ibrahim on 07/10/2021.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

