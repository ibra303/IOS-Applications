//
//  ViewController.swift
//  Magic 8 Ball
//
//  Created by Habib Naif Ibrahim on 08/10/2021.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var imageView1: UIImageView!
    let ballArray = ["ball1","ball2","ball3","ball4","ball5"]
    var randomBallNumber  : Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        newBallImage()
    }

    @IBAction func askButton(_ sender: Any) {
        newBallImage()
    }
    func newBallImage(){
        randomBallNumber = Int(arc4random_uniform(5))
        imageView1.image = UIImage(named: ballArray[randomBallNumber])
    }
    
    override func motionEnded(_ motion: UIEvent.EventSubtype, with event: UIEvent?) {
        newBallImage()
    }
}
