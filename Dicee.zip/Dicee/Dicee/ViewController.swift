//
//  ViewController.swift
//  Dicee
//
//  Created by Habib Naif Ibrahim on 08/10/2021.
//

import UIKit

class ViewController: UIViewController {
    
    var randomDiceIndex1 : Int = 0
    var randomDiceIndex2 : Int = 0
    
    let diceArr = [ "dice1" , "dice2" , "dice3" , "dice4" , "dice5" , "dice6" ]
    
    @IBOutlet weak var diceimageview1: UIImageView!
    @IBOutlet weak var diceimageview2: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        updateDice()
    }

    @IBAction func rollButtonPressed(_ sender: UIButton) {
        updateDice()
    }
    
    func updateDice(){
        
        randomDiceIndex1 = Int(arc4random_uniform(6))
        randomDiceIndex2 = Int(arc4random_uniform(6))
        //
        diceimageview1.image = UIImage(named : diceArr[randomDiceIndex1])
        diceimageview2.image = UIImage(named : diceArr[randomDiceIndex2])
        
    }
    override func motionEnded(_ motion: UIEvent.EventSubtype, with event: UIEvent?) {
        updateDice()
    }
}
